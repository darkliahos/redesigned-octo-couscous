﻿using TextMatch.business;
using Xunit;

namespace TextMatch.UnitTests
{
    public class StringMatcherTests
    {
        [Theory]
        [InlineData("Crosby Stills Nash Young", "Stills", 8)]
        [InlineData("Crosby Stills Nash Young", "Nash", 15)]
        [InlineData("Don't let me down", "Don't", 1)]
        [InlineData("Do Chickens have Talons", "have", 13)]
        [InlineData("K@.com is not an email address", "k@.com", 1)]
        public void GivenIHaveAnSubstringInAStringAtOnePosition_ThenOneValueShouldBeReturned(string text, string subText, int index)
        {
            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(new int[] { index }, result);
        }


        [Fact]
        public void GivenSubstringIsNotPresent_ThenReturnEmptyArray()
        {
            // Arrange
            var subText = "Serious";
            var text = "The Jokes on you";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(Enumerable.Empty<int>(), result);
        }

        [Fact]
        public void GivenWhenIhaveAnEmptyStringNoResultsShoulbBeReturned()
        {
            // Arrange
            var subText = "";
            var text = "The Jokes on you";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(Enumerable.Empty<int>(), result);
        }

        [Fact]
        public void GivenTheSubstringIsBiggerThanTheTextItShouldNotError()
        {
            // Arrange
            var subText = "Elephants love cheese";
            var text = "Animals";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(Enumerable.Empty<int>(), result);
        }


        [Fact]
        public void MulitmatchingString()
        {
            // Arrange
            var subText = "ll";
            var text = "Polly put the kettle on, polly put the kettle on, polly put the kettle on we’ll all have tea";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(new int[] { 3, 28, 53, 78, 82 }, result);
        }
    }
}