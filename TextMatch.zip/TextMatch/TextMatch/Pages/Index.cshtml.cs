﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using TextMatch.business;

namespace TextMatch.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly IStringMatcher stringMatcher;
        public string result { get; set; } = string.Empty;

        public IndexModel(ILogger<IndexModel> logger, IStringMatcher stringMatcher)
        {
            _logger = logger;
            this.stringMatcher = stringMatcher;
        }

        public void OnGet()
        {

        }
    }
}