﻿using Microsoft.AspNetCore.Mvc;
using TextMatch.business;
using TextMatch.Models;

namespace TextMatch.Controllers
{
    public class TextSearchController : Controller
    {
        private readonly IStringMatcher stringMatch;

        public TextSearchController(IStringMatcher stringMatch)
        {
            this.stringMatch = stringMatch;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(TextMatchInput input)
        {
            var result = "";
            var matches = stringMatch.StringMatch(input.Text, input.SubText);

            // Note I would have used Linq IsEmpty or IsAny here
            if (matches.Count() == 0)
            {
                result = "There is no output";
            }
            else
            {
                foreach (var match in matches)
                {
                    result += match + ", ";
                }
                result = result.TrimEnd().TrimEnd(',');
            }
            input.Result = result;

            return View(input);
        }
    }
}
