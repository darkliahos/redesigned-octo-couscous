﻿namespace TextMatch.Models
{
    public class TextMatchInput
    {
        public string Text { get; set; }

        public string SubText { get; set; }

        public string Result { get; set; }
    }
}
