﻿namespace TextMatch.business
{
    public class StringMatcher : IStringMatcher
    {
        public IEnumerable<int> StringMatch(string text, string subText)
        {
            var result = new List<int>();
            text = text.ToLower();
            subText = subText.ToLower();
            for(var i = 0; i < text.Length; i++)
            {
                int startingPosition = 0;

                startingPosition = SubStringSearch(text, subText, i);


                if (startingPosition != 0)
                {
                    result.Add(startingPosition);
                    i += subText.Length;
                }
            }
            return result;
        }

        private int SubStringSearch(string text, string subText, int currentIndex)
        {
            var index = currentIndex;
            var startingPosition = 0;
            for (var c = 0; c < subText.Length; c++)
            {
                if (text[index] != subText[c])
                {
                    startingPosition = 0;
                    break;
                }

                if (c == 0)
                {
                    startingPosition = currentIndex + 1;
                }
                index++;
            }
            return startingPosition;
        }
    }
}