﻿namespace TextMatch.business
{
    public interface IStringMatcher
    {
        IEnumerable<int> StringMatch(string text, string subText);
    }
}