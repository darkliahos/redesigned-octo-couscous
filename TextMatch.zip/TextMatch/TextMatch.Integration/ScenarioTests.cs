﻿using TextMatch.business;
using Xunit;

namespace TextMatch.Integration
{
    public class ScenarioTests
    {
        [Fact]
        public void ScenarioOne()
        {
            // Arrange
            var subText = "Polly";
            var text = "Polly put the kettle on, polly put the kettle on, polly put the kettle on we’ll all have tea";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(new int[] { 1, 26, 51 }, result);
        }

        [Fact]
        public void ScenarioTwo()
        {
            // Arrange
            var subText = "ll";
            var text = "Polly put the kettle on, polly put the kettle on, polly put the kettle on we’ll all have tea";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(new int[] { 3, 28, 53, 78, 82 }, result);
        }

        [Fact]
        public void ScenarioThree()
        {
            // Arrange
            var subText = "X";
            var text = "Polly put the kettle on, polly put the kettle on, polly put the kettle on we’ll all have tea";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(Enumerable.Empty<int>(), result);
        }

        [Fact]
        public void ScenarioFour()
        {
            // Arrange
            var subText = "Polx";
            var text = "Polly put the kettle on, polly put the kettle on, polly put the kettle on we’ll all have tea";

            // Act
            var stringMatcher = new StringMatcher();
            var result = stringMatcher.StringMatch(text, subText);


            // Assert
            Assert.Equal(Enumerable.Empty<int>(), result);
        }
    }
}